#!/bin/bash
#terraform init -backend=true -backend-config="region=us-east-1" -backend-config="bucket=redecard-terraform" -backend-config="key=ECS/DEV/pn_login/taskdefinitions.tfstate"

SIGLA="pn_login"
TFSTATE="taskdefinitions.tfstate"

echo $1
case $1 in
  "development")
    clear
    echo "Iniciando a configuração do $TFSTATE de $1..."
    echo
    terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=ECS/DEV/$SIGLA/$TFSTATE" -backend-config="region=us-east-1"
    terraform apply -var-file=development.tfvars -auto-approve
  ;;
        [2])
            clear
		        echo "Iniciando a configuração do $TFSTATE de Desenvolvimento..."
		        echo
            terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/DEV/$TFSTATE" -backend-config="region=us-east-1"
            ;;
        [3])
            clear
		        echo "Iniciando a configuração do $TFSTATE de Homologação..."
		        echo
            terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/HOM/$TFSTATE" -backend-config="region=us-east-1"
            ;;
        [4])
            clear
		        echo "Iniciando a configuração do $TFSTATE de Produção..."
		        echo
            terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/PRD/$TFSTATE" -backend-config="region=us-east-1"
esac
exit

