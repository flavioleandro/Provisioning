GY3 with terraform
1 - VPC
2 - Security Group
3 - Auto Scaling
4 - RDS
5 - SQS

contempla a criacao de vpc peering com pg
apos o provisionamento da vpc do pg deve se executar 

6 - vpc peering
7 - route para vpc peering
