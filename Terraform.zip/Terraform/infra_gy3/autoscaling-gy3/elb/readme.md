https://github.com/terraform-community-modules/tf_aws_elb

https://www.terraform.io/docs/providers/aws/r/elb.html#availability_zones
