https://github.com/unifio/terraform-aws-asg
exemplo
https://github.com/terraform-providers/terraform-provider-aws/issues/3689
