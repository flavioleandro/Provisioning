#!/bin/bash

SIGLA="GRAYLOG"
TFSTATE="access.tfstate"

case $1 in
  "development")
    terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/Hml/$TFSTATE" -backend-config="region=us-east-1"
    #terraform apply -var-file=development.tfvars -auto-approve
  ;;
  "production")
    terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/INFRA/$TFSTATE" -backend-config="region=us-east-1"
    #terraform apply -var-file=production.tfvars -auto-approve
esac
