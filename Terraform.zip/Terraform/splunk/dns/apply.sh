#!/bin/bash
#terraform init -backend=true -backend-config="region=us-east-1" -backend-config="bucket=redecard-terraform" -backend-config="key=ECS/DEV/pn_login/taskdefinitions.tfstate"

SIGLA="splunk"
TFSTATE="dns.tfstate"

echo $1
clear
echo "Iniciando a configuração do $TFSTATE de $1..."
echo
case $1 in
  "development")
    terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/DEV/$TFSTATE" -backend-config="region=us-east-1"
    terraform apply -var-file=development.tfvars -var-file=../common.tfvars
  ;;
  "homologation")
    terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/HOM/$TFSTATE" -backend-config="region=us-east-1"
    terraform apply -var-file=homologation.tfvars -var-file=../common.tfvars
  ;;
  "production")
    terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/PRD/$TFSTATE" -backend-config="region=us-east-1"
    terraform apply -var-file=production.tfvars -var-file=../common.tfvars
  ;;
esac
exit
