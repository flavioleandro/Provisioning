#!/bin/bash
#terraform init -backend=true -backend-config="region=us-east-1" -backend-config="bucket=redecard-terraform" -backend-config="key=ECS/DEV/pn_login/taskdefinitions.tfstate"

SIGLA="splunk"
TFSTATE="master.tfstate"

echo $1
case $1 in
  "homologation")
    clear
    echo "Iniciando a configuração do $TFSTATE de $1..."
    echo
    terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/HOM/$TFSTATE" -backend-config="region=us-east-1"
    terraform apply -var-file=homologation.tfvars -var-file=../../common.tfvars
  ;;
  "production")
    clear
    echo "Iniciando a configuração do $TFSTATE de $1..."
    echo
    terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/PRD/$TFSTATE" -backend-config="region=us-east-1"
    terraform apply -var-file=production.tfvars -var-file=../../common.tfvars
  ;;
        [3])
            clear
		        echo "Iniciando a configuração do $TFSTATE de Homologação..."
		        echo
            terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/HOM/$TFSTATE" -backend-config="region=us-east-1"
            ;;
        [4])
            clear
		        echo "Iniciando a configuração do $TFSTATE de Produção..."
		        echo
            terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/PRD/$TFSTATE" -backend-config="region=us-east-1"
esac
exit
