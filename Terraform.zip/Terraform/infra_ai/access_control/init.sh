#!/bin/bash

if [ $# -eq 0 ]
then
	echo
	echo "Favor informar um ambiente como argumento."
	echo $0" <ci | development | homolog | production>"
	echo
	exit 1
fi

case $1 in
	ci | CI)
	AMBIENTE="CI"
	;;
  development | DEVELOPMENT | dev | DEV)
	AMBIENTE="DEV"
	;;
	homolog | HOMOLOG | hom | HOM)
	AMBIENTE="HOM"
	;;
	production | PRODUCTION | prd | PRD)
	AMBIENTE="PRD"
	;;
	*)
	echo
	echo "Favor informar um ambiente como argumento."
	echo $0" <ci | development | homolog | production>"
	echo
	exit 1
esac

# ambiente=$1
# AMBIENTE=${ambiente^^}

terraform init -backend=true -backend-config="key=AI/$AMBIENTE/access_control.tfstate"
terraform apply -var-file=$AMBIENTE".tfvars" -var-file="../common.tfvars" #-auto-approve
