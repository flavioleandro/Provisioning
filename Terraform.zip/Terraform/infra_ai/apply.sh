#!/bin/bash

# check if stdout is a terminal...
if test -t 1; then

    # see if it supports colors...
    ncolors=$(tput colors)

    if test -n "$ncolors" && test $ncolors -ge 8; then
        bold="$(tput bold)"
        underline="$(tput smul)"
        standout="$(tput smso)"
        normal="$(tput sgr0)"
        black="$(tput setaf 0)"
        red="$(tput setaf 1)"
        green="$(tput setaf 2)"
        yellow="$(tput setaf 3)"
        blue="$(tput setaf 4)"
        magenta="$(tput setaf 5)"
        cyan="$(tput setaf 6)"
        white="$(tput setaf 7)"
    fi
fi

if [ $# -eq 0 ]
then
	echo
	echo "Favor informar um ambiente como argumento."
	echo ${bold}$0${normal}" <${green} ci${normal} | ${cyan}development${normal} | ${yellow}homolog${normal} | ${red}production${normal} >"
	echo
	exit 1
fi

case $1 in
	ci | CI)
	AMBIENTE="CI"
	;;
  development | DEVELOPMENT | dev | DEV)
	AMBIENTE="DEV"
	;;
	homolog | HOMOLOG | hom | HOM)
	AMBIENTE="HOM"
	;;
	production | PRODUCTION | prd | PRD)
	AMBIENTE="PRD"
	;;
	*)
	echo
	echo "Favor informar um ambiente como argumento."
	echo ${bold}$0${normal}" <${green} ci${normal} | ${cyan}development${normal} | ${yellow}homolog${normal} | ${red}production${normal} >"
	echo
	exit 1
esac

#ambiente=$1
#AMBIENTE=${ambiente^^}

REPOSITORIO="infra_ai"

var[1]="network"
var[2]="access_control"
var[3]="services"
var[4]="services/commercial-terms"

INICIO=$(date "+%Y/%m/%d %H:%M:%S")
OUTPUT=$HOME/$REPOSITORIO/"output"$(date "+%Y%m%d%H%M")".log"
APPLY=$HOME/$REPOSITORIO/"apply"$(date "+%Y%m%d%H%M")".log"

echo
echo "========================================================================="
echo

for i in 1 2 3 4
do
	cd $HOME/$REPOSITORIO/${var[i]}
	sh init.sh $AMBIENTE #>> $APPLY
	# terraform output >> $OUTPUT
	# echo >> $OUTPUT
	# echo "=========================================================================" >> $OUTPUT
	# echo >> $OUTPUT
	if [ "$?" -ne "0" ]
		then
			echo
			echo "Erro na criação dos recursos!!!"
			echo "Verifique o erro ocorrido em $APPLY"
			break
		else
			echo
			echo "${cyan}Recursos de${bold} ${var[i]} ${normal}${cyan}criados com sucesso!${normal}"
			sleep 5
	fi
done

echo
echo "Consulte os outputs dos recursos criados em $OUTPUT"
echo
echo "${bold}${green}=========================================================================${normal}"
echo "${yellow}$INICIO - Inicio do script de criação de recursos.${normal}"
echo ${yellow}$(date "+%Y/%m/%d %H:%M:%S")" - Final do script de criação de recursos.${normal}"
echo
