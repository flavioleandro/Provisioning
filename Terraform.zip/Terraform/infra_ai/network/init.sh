#!/bin/bash

if [ $# -eq 0 ]
then
	echo
	echo "Favor informar um ambiente como argumento."
	echo $0" <CI | DEV | HOM | PRD>"
	echo
	exit 1
fi

case $1 in
	ci | CI)
	AMBIENTE="CI"
	;;
  development | DEVELOPMENT | dev | DEV)
	AMBIENTE="DEV"
	;;
	homolog | HOMOLOG | hom | HOM)
	AMBIENTE="HOM"
	;;
	production | PRODUCTION | prd | PRD)
	AMBIENTE="PRD"
	;;
	*)
	echo
	echo "Favor informar um ambiente como argumento."
	echo $0" <ci | development | homolog | production>"
	echo
	exit 1
esac

# ambiente=$1
# AMBIENTE=${ambiente^^}

terraform init -backend=true -backend-config="key=AI/$AMBIENTE/network.tfstate"
terraform apply -var-file="tfvars/"$AMBIENTE".tfvars" -var-file="../common.tfvars" #-auto-approve
