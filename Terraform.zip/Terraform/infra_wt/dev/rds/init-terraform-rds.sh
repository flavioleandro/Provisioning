../../../terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=WT/DEV/rds-wt.tfstate" -backend-config="region=us-east-1"
