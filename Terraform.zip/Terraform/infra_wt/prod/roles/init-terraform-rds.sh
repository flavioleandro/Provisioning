terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=WT/PROD/roles-wt.tfstate" -backend-config="region=us-east-1"
