terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=WT/PROD/SB/vpc-wt.tfstate" -backend-config="region=us-east-1"
