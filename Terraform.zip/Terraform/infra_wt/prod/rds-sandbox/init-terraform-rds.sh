#!/bin/bash

TFSTATE="rds-wt.tfstate"
SIGLA="WT"

clear
echo "Você está provisionando qual ambiente?"
echo
echo "1- CI"
echo "2- Desenvolvimento"
echo "3- Homologação"
echo "4- Produção"
echo "5- INFRA"
echo "6- SB Homologação"
echo "7- SB Produção"
echo
read -p "Digite a opção correspondente (de 1 a 7): " OPCAO

while [ "$OPCAO" = "" ] || [ $OPCAO -lt 1 ] || [ $OPCAO -gt 7 ]
do
        echo "Valor inválido!"
        read -p "Digite uma opção de 1 a 5: " OPCAO
done

case "$OPCAO" in
        [1])
		        clear
		        echo "Iniciando a configuração do $TFSTATE de CI..."
            echo
		        terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/CI/$TFSTATE" -backend-config="region=us-east-1"
            ;;
        [2])
            clear
		        echo "Iniciando a configuração do $TFSTATE de Desenvolvimento..."
		        echo
            terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/DEV/$TFSTATE" -backend-config="region=us-east-1"
            ;;
        [3])
            clear
		        echo "Iniciando a configuração do $TFSTATE de Homologação..."
		        echo
            terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/HOM/$TFSTATE" -backend-config="region=us-east-1"
            ;;
        [4])
            clear
		        echo "Iniciando a configuração do $TFSTATE de Produção..."
		        echo
            terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/PROD/$TFSTATE" -backend-config="region=us-east-1"
            ;;	
	[5])
            clear
		        echo "Iniciando a configuração do $TFSTATE de INFRA..."
		        echo
            terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/INFRA/$TFSTATE" -backend-config="region=us-east-1"
            ;;	
	[6])
            clear
		        echo "Iniciando a configuração do $TFSTATE de SB Homologação..."
		        echo
            terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/HOM/SB/$TFSTATE" -backend-config="region=us-east-1"
            ;;	
	[7])
            clear
		        echo "Iniciando a configuração do $TFSTATE de SB Produção..."
		        echo
            terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/PROD/SB/$TFSTATE" -backend-config="region=us-east-1"			
esac
exit
