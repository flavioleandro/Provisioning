terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=WT/HOM/SB/sg-wt.tfstate" -backend-config="region=us-east-1"
