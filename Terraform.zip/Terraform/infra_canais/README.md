Demanda do time de Canais "Credenciamento"

Provisionado um bucket S3 e um cloudfront (dentro da sigla PI3)
