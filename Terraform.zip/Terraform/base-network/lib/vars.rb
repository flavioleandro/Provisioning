require 'yaml'
require 'ostruct'

module Vars
  class << self
    def load_vars(file)
      YAML.load_file(file).to_a.reduce(OpenStruct.new) do |acc, var|
        var_name = var[0]
        var_value = var[1]

        acc.send("#{var_name}=", var_value)
        acc
      end
    end
  end
end
