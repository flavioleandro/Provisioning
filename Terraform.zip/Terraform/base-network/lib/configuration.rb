require_relative 'paths'
require_relative 'vars'
require 'ostruct'

class Configuration
  def initialize
  end

  def work_directory
    'build'
  end

  def parameters
    config = {
      source_directory: Paths.from_project_root_directory('spec', 'infra'),
      work_directory: work_directory,
      state_file: Paths.from_project_root_directory('state', 'spec.tfstate'),
      vars: Vars.load_vars(Paths.from_project_root_directory('config', 'vars', 'variables.yml'))
    }

    OpenStruct.new(config)
  end
end
