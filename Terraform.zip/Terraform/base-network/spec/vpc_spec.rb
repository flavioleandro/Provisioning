require 'spec_helper'

describe :vpc do
  let(:vpc_out) { output_for('vpc_out') }
  subject { vpc('base-network-test') }

  it { is_expected.to exist }
  it { is_expected.to be_available }

  it 'exposes the vpc id as an output' do
    expected_vpc_id = subject.vpc_id
    actual_vpc_id = vpc_out['vpc_id']
    
    expect(actual_vpc_id).to(eq(expected_vpc_id))
  end

  it 'exposes the vpc cidr as an output' do
    expected_vpc_cidr = subject.cidr_block
    actual_vpc_cidr = vpc_out['vpc_cidr_block']

    expect(actual_vpc_cidr).to(eq(expected_vpc_cidr))
  end

end

