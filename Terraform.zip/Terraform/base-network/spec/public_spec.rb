require 'spec_helper'

describe 'public' do
  let(:created_vpc) { vpc('base-network-test') }
  let(:public_2a) { subnet('base-network-test-public-us-east-2a') }
  let(:public_2b) { subnet('base-network-test-public-us-east-2b') }
  let(:public_route_table) { route_table('base-network-test-public') }
  let(:igw) { internet_gateway('base-network-test-igw') }

  context 'subnets' do
    it 'has a subnet in us-east-2a' do
      expect(public_2a.availability_zone).to(eq('us-east-2a'))
    end
    it 'has a subnet in us-east-2b' do
      expect(public_2b.availability_zone).to(eq('us-east-2b'))
    end
    it 'associates each subnet with the created vpc' do
      expect(public_2a.vpc_id).to(eq(created_vpc.vpc_id))
      expect(public_2b.vpc_id).to(eq(created_vpc.vpc_id))
    end
  end

  context 'route table' do
    it 'associates with the created vpc' do
      expect(public_route_table.vpc_id)
        .to(eq(created_vpc.vpc_id))
    end
    it 'associates with each public subnet' do
      expect(public_route_table).to(have_subnet(public_2a.id))
      expect(public_route_table).to(have_subnet(public_2b.id))
    end
    it 'has a route to the internet' do
      expect(public_route_table)
        .to(have_route('0.0.0.0/0').target(gateway: igw.internet_gateway_id))
    end
  end
end
