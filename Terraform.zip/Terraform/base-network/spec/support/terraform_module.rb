require 'ruby_terraform'
require_relative '../../lib/configuration'

module TerraformModule
  class << self
    def configuration
      @configuration ||= Configuration.new
    end

    def output_for(name)
      RubyTerraform.output(
        name: name,
        state: configuration.parameters.state_file
      )
    end

    def provision
      FileUtils.rm_rf(configuration.parameters.work_directory)
      FileUtils.mkdir_p(configuration.parameters.work_directory)
      FileUtils.cp_r(
        "#{configuration.parameters.source_directory}/.",
        configuration.parameters.work_directory
      )

      Dir.chdir(configuration.parameters.work_directory) do
        RubyTerraform.init
        RubyTerraform.apply(
          directory: '.',
          state: configuration.parameters.state_file,
          auto_approve: true,
          vars: configuration.parameters.vars.to_h
        )
      end
    end

    def teardown
      FileUtils.rm_rf(configuration.parameters.work_directory)
      FileUtils.mkdir_p(configuration.parameters.work_directory)
      FileUtils.cp_r(
        "#{configuration.parameters.source_directory}/.",
        configuration.parameters.work_directory
      )

      Dir.chdir(configuration.parameters.work_directory) do
        RubyTerraform.init
        RubyTerraform.destroy(
          directory: '.',
          state: configuration.parameters.state_file,
          force: true,
          vars: configuration.parameters.vars.to_h
        )
      end
    end
  end
end
