require_relative '../terraform_module'
require 'json'

shared_context :terraform do

  let(:vars) { TerraformModule.configuration.parameters.vars }

  def output_for(name)
    out_json = JSON.parse(TerraformModule.output_for("-json #{name}"))
    out_json['value']
  end

end
