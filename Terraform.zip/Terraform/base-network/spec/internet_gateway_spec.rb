require 'spec_helper'

describe 'internet gateway' do
  let(:created_vpc) { vpc('base-network-test') }

  subject { internet_gateway('base-network-test-igw') }

  it { should exist }

  it 'is attached to the created vpc' do
    expect(subject).to(be_attached_to(created_vpc.vpc_id))
  end
end
