require 'spec_helper'

describe 'private' do
  let(:created_vpc) { vpc('base-network-test') }
  let(:private_2a) { subnet('base-network-test-private-us-east-2a') }
  let(:private_2b) { subnet('base-network-test-private-us-east-2b') }
  let(:database_2a) { subnet('base-network-test-db-us-east-2a') }
  let(:database_2b) { subnet('base-network-test-db-us-east-2b') }
  let(:private_route_table2a) { route_table('base-network-test-private-us-east-2a') }
  let(:private_route_table2b) { route_table('base-network-test-private-us-east-2b') }

  context 'subnets' do
    it 'has a subnet in us-east-2a' do
      expect(private_2a.availability_zone).to(eq('us-east-2a'))
    end
    it 'has a subnet in us-east-2b' do
      expect(private_2b.availability_zone).to(eq('us-east-2b'))
    end
    it 'associates its subnets with the created vpc' do
      expect(private_2a.vpc_id).to(eq(created_vpc.vpc_id))
      expect(private_2b.vpc_id).to(eq(created_vpc.vpc_id))
    end
  end

  context 'route tables' do
    it 'associates a route table with zone us-east-2a' do
      expect(private_route_table2a)
        .to(have_subnet(private_2a.id))
      expect(private_route_table2a)
        .to(have_subnet(database_2a.id))
    end
    it 'associates a route table with zone us-east-2b' do
      expect(private_route_table2b)
        .to(have_subnet(private_2b.id))
      expect(private_route_table2b)
        .to(have_subnet(database_2b.id))
    end
    it 'associates the route tables with the created vpc' do
      expect(private_route_table2a.vpc_id)
        .to(eq(created_vpc.vpc_id))
      expect(private_route_table2b.vpc_id)
        .to(eq(created_vpc.vpc_id))
    end
  end
end
