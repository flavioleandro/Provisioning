require 'awspec'
require_relative 'support/terraform_module'
require_relative 'support/shared_contexts/terraform'

RSpec.configure do |config|
  config.include_context :terraform

  config.before(:suite) do
    TerraformModule.provision
  end

  config.after(:suite) do
    TerraformModule.teardown
  end
end
