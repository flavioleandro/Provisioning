#!/bin/bash

if [ $# -eq 0 ]
then
	echo
	echo "Favor informar um ambiente como argumento."
	echo $0" <HOM | PRD>"
	echo
	exit 1
fi

case $1 in
	homolog | HOMOLOG | hom | HOM)
	AMBIENTE="HOM"
	;;
	production | PRODUCTION | prd | PRD)
	AMBIENTE="PRD"
	;;
	*)
	echo
	echo "Favor informar um ambiente como argumento."
	echo $0" <homolog | production>"
	echo
	exit 1
esac

# ambiente=$1
# AMBIENTE=${ambiente^^}

terraform init -backend=true -backend-config="key=AI/$AMBIENTE/services.tfstate"
terraform apply -var-file=$AMBIENTE".tfvars" -var-file="../common.tfvars" #-auto-approve
