...Comando para inicializar o terraform
#terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=PI3/CI/vpc-pi3.tfstate" -backend-config="region=us-east-1"

#terraform init -backend=<true> -backend-config="<nome do bucket>" -backend-config="key=<diretorio dento do bucket/nome do arquivo.tfstate>" -backend-config="region=<regiao do bucket>"

#

 - Pre requisito intalar o awscli-bundle no servidor que vai rodar o terraform.

https://docs.aws.amazon.com/pt_br/cli/latest/userguide/awscli-install-bundle.html

$ curl "https://s3.amazonaws.com/aws-cli/awscli-bundle.zip" -o "awscli-bundle.zip"
$ unzip awscli-bundle.zip
$ ./awscli-bundle/install -b ~/bin/aws
#

Inventario de provisionamento CI
 - vpc.
 - sg (incompleto, somente ssh, web e rds)
 - sqs
 - redis
 - S3
 - elastic search
  - 53 - ok
  - ???
 - rds
 - lambda
    - server manager - ok
    - p-ctrlrd-lambda-parser-integration - ok
        - aguardando levantamento do Denis
 - beanstalk
  - Application - ok
     - integration-api - ok
     - acquirer-report-builder - ok
     - notification-api - ok
     - login - ok
     - splitter - ok
     - entity-manager-integration-env - ok
     - notification-api - ok
     - backffice - ok
     - API - ok
     - parser
     - parser-integration
     - entity-manager
     - admin
