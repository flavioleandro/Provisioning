Codigo terraform para provisionamento de infraestrutura para ambiente de stress da sigla MX5 (maxiPago)

# OBJETIVO

Realizar o provisionamento de infraestrutura na AWS do ambiente de crise da maxiPago.
Com o código deste projeto é possível criar e destruir o ambiente conforme a necessidade de uso, otimizando o gasto com este ambiente.

# PRÉ REQUISITOS

- Terraform instalado
- Git client instalado
- Credenciais AWS para criação de recursos na conta da maxiPago (access key ou role).
- Certificado "Rede Intermediate CA" instalado no servidor para acesso ao GitLab REDE com HTTPs
- Credenciais no GitLab REDE

# DEPENDENCIAS
 Bucket S3 **maxipago-terraform** criado na conta AWS da maxiPago.
 Nesse bucket sao armanezados os arquivos de estado do terraform.

# MELHORIAS QUE PRECISAO SER IMPLEMENTADAS

- Passagem de valor para parametros aliases do CloudFront

