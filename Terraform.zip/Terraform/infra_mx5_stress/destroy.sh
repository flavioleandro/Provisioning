#!/bin/bash

#Destruindo Route53
clear
echo "Destruindo Route53"
cd route53/
sh init.sh
sh destroy.sh
cd ..

#Destruindo RDS
clear
echo "Destruindo RDS"
cd rds/
sh init.sh
sh destroy.sh
cd ..

#Criando CloudFront
clear
echo "Criando CloudFront"
cd cloudfront/
sh init.sh
sh destroy.sh
cd ..
sleep 10

#Destruindo AutoScaling
clear
echo "Destruindo AutoScaling"
cd autoscaling/
sh init.sh
sh destroy.sh
cd ..

#Destruindo VPC
clear
echo "Destruindo VPC"
cd vpc/
sh init.sh
sh destroy.sh
cd ..
