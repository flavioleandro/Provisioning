#!/bin/bash

#Criando VPC
clear
echo "Criando VPC"
cd vpc/
sh init.sh
sh apply.sh
cd ..
sleep 10

#Criando AutoScaling
clear
echo "Criando AutoScaling"
cd autoscaling/
sh init.sh
sh apply.sh
cd ..
sleep 10

#Criando CloudFront
clear
echo "Criando CloudFront"
cd cloudfront/
sh init.sh
sh apply.sh
cd ..
sleep 10

#Criando RDS
clear
echo "Criando RDS"
cd rds/
sh init.sh
sh apply.sh
cd ..

#Criando Route53
clear
echo "Criando Route53"
cd route53/
sh init.sh
sh apply.sh
cd ..

