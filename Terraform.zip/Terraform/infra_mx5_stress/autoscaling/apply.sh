#!/bin/bash
terraform apply -auto-approve

