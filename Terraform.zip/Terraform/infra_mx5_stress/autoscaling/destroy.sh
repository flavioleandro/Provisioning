#!/bin/bash
terraform destroy -auto-approve

