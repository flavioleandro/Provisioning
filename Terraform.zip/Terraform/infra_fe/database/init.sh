#!/bin/bash

if [ $# -eq 0 ]
then
                echo
        echo "Favor informar um ambiente como argumento."
        echo $0" <CI | DEV | HOM | PRD>"
        echo
        exit 1
fi

ambiente=$1
AMBIENTE=${ambiente^^}

terraform init -backend=true -backend-config="key=FE-CI/$AMBIENTE/rds.tfstate"
terraform apply -var-file=$AMBIENTE".tfvars" #-auto-approve
