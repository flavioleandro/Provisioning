Padrao de estrutura do terraform
