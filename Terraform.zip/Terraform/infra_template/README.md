template para estrutura dos códigos terraform
