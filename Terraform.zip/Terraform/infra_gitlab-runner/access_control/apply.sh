#!/bin/bash

SIGLA="GITLAB"
TFSTATE="access_control.tfstate"

terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/INFRA/$TFSTATE" -backend-config="region=us-east-1"
#terraform apply -var-file=ci.tfvars -auto-approve
