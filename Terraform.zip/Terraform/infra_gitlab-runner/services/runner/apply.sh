#!/bin/bash

SIGLA="GITLAB"
TFSTATE="runner.tfstate"

case $1 in
  "development")
    terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/DEV/$TFSTATE" -backend-config="region=us-east-1"
    terraform apply -var-file=development.tfvars #-auto-approve
  ;;
  "production")
    terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/INFRA/$TFSTATE" -backend-config="region=us-east-1"
    terraform apply -var-file=production.tfvars #-auto-approve
esac
