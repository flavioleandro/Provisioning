Autoscaling GitLab Runner on AWS
https://docs.gitlab.com/runner/configuration/runner_autoscale_aws/

Docker Machine (MachineOptions)
https://docs.docker.com/machine/drivers/aws/#options