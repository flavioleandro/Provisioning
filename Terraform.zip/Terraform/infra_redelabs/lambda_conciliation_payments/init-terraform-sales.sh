#!/bin/bash

TFSTATE="conciliation-payments.tfstate"
SIGLA="RL7"

clear
echo "Você está provisionando qual ambiente?"
echo
echo "1- CI"
echo "2- Desenvolvimento"
echo "3- Homologação"
echo "4- Produção"
echo
read -p "Digite a opção correspondente (de 1 a 4): " OPCAO

while [ "$OPCAO" = "" ] || [ $OPCAO -lt 1 ] || [ $OPCAO -gt 4 ]
do
        echo "Valor inválido!"
        read -p "Digite uma opção de 1 a 4: " OPCAO
done

case "$OPCAO" in
        [1])
		        clear
		        echo "Iniciando a configuração do $TFSTATE de CI..."
            echo
		        terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/CI/lambda/$TFSTATE" -backend-config="region=us-east-1"
            ;;
        [2])
            clear
		        echo "Iniciando a configuração do $TFSTATE de Desenvolvimento..."
		        echo
            terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/DEV/lambda/$TFSTATE" -backend-config="region=us-east-1"
            ;;
        [3])
            clear
		        echo "Iniciando a configuração do $TFSTATE de Homologação..."
		        echo
            terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/HOM/lambda/$TFSTATE" -backend-config="region=us-east-1"
            ;;
        [4])
            clear
		        echo "Iniciando a configuração do $TFSTATE de Produção..."
		        echo
            terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/PRD/lambda/$TFSTATE" -backend-config="region=us-east-1"
esac
exit
