#!/bin/bash
SIGLA="RL7"
TFSTATE="database.tfstate"

echo "Iniciando a configuração do $TFSTATE de $1..."

case $1 in
  "development")
    terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/DEV/$TFSTATE" -backend-config="region=us-east-1"
    #terraform apply -var-file=development.tfvars -auto-approve
  ;;
  "homologation")
    terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/HOM/$TFSTATE" -backend-config="region=us-east-1"
    #terraform apply -var-file=homologation.tfvars -auto-approve
  ;;
  "production")
    terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/PRD/$TFSTATE" -backend-config="region=us-east-1"
    #terraform apply -var-file=production.tfvars -auto-approve
  ;;
esac

exit
