#!/bin/bash

echo "ECS_CLUSTER=${ecs_cluster_name}" >> /etc/ecs/ecs.config
echo "ECS_ENGINE_AUTH_TYPE=dockercfg" >> /etc/ecs/ecs.config
echo 'ECS_ENGINE_AUTH_DATA={"docker.artifactoryci.prd.useredecloud":{"auth":"ZG9ja2VyX2NpOnJlZGVfZG9ja2VyX2Np"}}' >> /etc/ecs/ecs.config
echo ECS_AVAILABLE_LOGGING_DRIVERS='["splunk","awslogs"]' >> /etc/ecs/ecs.config

mkdir /root/.docker
echo '{
	    "auths": {
          "docker.artifactoryci.prd.useredecloud": {
	        "auth": "ZG9ja2VyX2NpOnJlZGVfZG9ja2VyX2Np"
            }
	    },
	    "HttpHeaders": {
	      "User-Agent": "Docker-Client/18.03.1-ce (linux)"
	    }
      }' >> /root/.docker/config.json

#Adicionando o Artifactory CI como repositorio docker  inseguro
OPTION=`cat /etc/sysconfig/docker | grep "OPTIONS" | grep -v "#"`
OPTION_NEW="$${OPTION::-1}"
OPTION_NEW+=' --insecure-registry=docker.artifactoryci.prd.useredecloud"'
echo "$OPTION_NEW" >> /root/userdata.log

sleep 15

cp /etc/sysconfig/docker /root/docker_bkp #backup do arquivo original
sed -ie "s/$OPTION/$OPTION_NEW/" /etc/sysconfig/docker

sleep 15

#Restart do docker e agent ecs
service docker restart
docker start ecs-agent

if [ "${appdynamics_machineagent_enable}" = "true" ]
then
	docker run -d --restart=always -e "JAVA_PARAMETERS=-Dappdynamics.controller.hostName=${app_hostName} -Dappdynamics.controller.port=8090 -Dappdynamics.controller.ssl.enabled=false -Dappdynamics.agent.accountName=${app_accountName} -Dappdynamics.agent.accountAccessKey=${app_accountAccessKey} -Dappdynamics.sim.enabled=True -Dappdynamics.docker.enabled=True" -v /:/hostroot:ro -v /var/run/docker.sock:/var/run/docker.sock --privileged=true ${artifactory_url}/appdynamics_machineagent:4.3.4.3
fi
