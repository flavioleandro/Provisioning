terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=SQT/DEV/SonarQube.tfstate" -backend-config="region=us-east-1"
