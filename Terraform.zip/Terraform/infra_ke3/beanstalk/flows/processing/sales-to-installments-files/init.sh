#!/bin/bash

TFSTATE="sales-to-installments-files.tfstate"
SIGLA="KE3"

if [ $# -eq 0 ]
then
	echo
	echo "Favor informar um ambiente como argumento."
	echo " < ci | development | homolog | production >"
	echo
	exit 1
fi

case $1 in
  [1] | CI | ci)
        echo
        echo "Iniciando a configuração do $TFSTATE de CI..."
        terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/CI/eb-flow-ke3/$TFSTATE" -backend-config="region=us-east-1"
        terraform apply -input=false -var 'environment=CI'
        ;;
  [2] | development | DEVELOPMENT | dev | DEV)
        echo
        echo "Iniciando a configuração do $TFSTATE de Desenvolvimento..."
        terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/DEV/eb-flow-ke3/$TFSTATE" -backend-config="region=us-east-1"
        terraform apply -input=false -var 'environment=DEV'
        ;;
  [3] | homolog | HOMOLOG | hom | HOM)
        echo
        echo "Iniciando a configuração do $TFSTATE de Homologação..."
        terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/HOM/eb-flow-ke3/$TFSTATE" -backend-config="region=us-east-1"
        terraform apply -input=false -var 'environment=HOM'
        ;;
  [4] | production | PRODUCTION | prd | PRD)
        echo
        echo "Iniciando a configuração do $TFSTATE de Produção..."
        terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/PRD/eb-flow-ke3/$TFSTATE" -backend-config="region=us-east-1"
        terraform apply -input=false -var 'environment=PRD'
        ;;
  *)
        echo
        echo "Favor informar um ambiente como argumento."
        echo " < ci | development | homolog | production >"
        echo
        exit 1

esac
exit
