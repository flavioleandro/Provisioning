#!/bin/bash

# check if stdout is a terminal...
if test -t 1; then

    # see if it supports colors...
    ncolors=$(tput colors)

    if test -n "$ncolors" && test $ncolors -ge 8; then
        bold="$(tput bold)"
        underline="$(tput smul)"
        standout="$(tput smso)"
        normal="$(tput sgr0)"
        black="$(tput setaf 0)"
        red="$(tput setaf 1)"
        green="$(tput setaf 2)"
        yellow="$(tput setaf 3)"
        blue="$(tput setaf 4)"
        magenta="$(tput setaf 5)"
        cyan="$(tput setaf 6)"
        white="$(tput setaf 7)"
    fi
fi

if [ $# -eq 0 ]
then
	echo
	echo "Favor informar como argumento a ação desejada."
	echo $0" < plan | apply | destroy >"
	echo
	exit 1
fi

REPOSITORIO="infra_ke3"

var[1]="dynamodb/flow/adjustmentTypes"
var[2]="dynamodb/flow/anticipations"
var[3]="dynamodb/flow/bankAccounts"
var[4]="dynamodb/flow/banks"
var[5]="dynamodb/flow/brands"
var[6]="dynamodb/flow/cancellations"
var[7]="dynamodb/flow/cashback"
var[8]="dynamodb/flow/chargebacks"
var[9]="dynamodb/flow/charges"
var[10]="dynamodb/flow/creditOrders"
var[11]="dynamodb/flow/installments"
var[12]="dynamodb/flow/payments"
var[13]="dynamodb/flow/paymentscreditOrders"
var[14]="dynamodb/flow/pvs"
var[15]="dynamodb/flow/receivables"
var[16]="dynamodb/flow/sales"
var[17]="dynamodb/flow/terminals"

INICIO=$(date "+%Y/%m/%d %H:%M:%S")
OUTPUT=$HOME/$REPOSITORIO/"output"$(date "+%Y%m%d%H%M")".log"
APPLY=$HOME/$REPOSITORIO/"apply"$(date "+%Y%m%d%H%M")".log"

echo
echo "========================================================================="
echo

for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17
do
	cd $HOME/$REPOSITORIO/${var[i]}
  if [ "$1" = "plan" ]
  then
    sh init.sh plan
    elif [ "$1" = "apply" ]
    then
      sh init.sh apply
    elif [ "$1" = "destroy" ]
    then
      sh init.sh destroy
    else
      echo
      echo "A ação digitada não existe... use:"
      echo $0" < plan | apply | destroy >"
      echo
      exit 1
  fi
	if [ "$?" -ne "0" ]
		then
			echo
			echo "Erro na criação dos recursos!!!"
			echo "Verifique o erro ocorrido em $APPLY"
			#break
      continue
		else
			echo
			echo "${cyan}Terraform $1 do recurso${bold} ${var[i]} ${normal}${cyan}executado com sucesso!${normal}"
			sleep 5
	fi
done

echo
echo "Consulte os outputs dos recursos criados em $OUTPUT"
echo
echo "${bold}${green}=========================================================================${normal}"
echo "${yellow}$INICIO - Inicio do script de criação de recursos.${normal}"
echo ${yellow}$(date "+%Y/%m/%d %H:%M:%S")" - Final do script de criação de recursos.${normal}"
echo
