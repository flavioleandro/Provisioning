#!/bin/bash

TFSTATE="anticipation-persistence.tfstate"
SIGLA="KE3"

ACCOUNT_ID=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep accountId | awk '{print $3}'|tr -d \"\,)

if [ $# -eq 0 ]
then
	echo
	echo "Favor informar como argumento a ação desejada."
	echo $0" < plan | apply | destroy >"
	echo
	exit 1
fi

case $ACCOUNT_ID in
	864401998850)
	  echo
	  echo "Iniciando a configuração do $TFSTATE de CI..."
	  terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/CI/lambda-ke3/$TFSTATE" -backend-config="region=us-east-1"
		if [ "$1" = "plan" ]
	  then
	    terraform plan -input=false -var 'environment=CI'
			elif [ "$1" = "apply" ]
	    then
	      terraform apply -input=false -var 'environment=CI'
			elif [ "$1" = "destroy" ]
	    then
	      terraform destroy -input=false -var 'environment=CI'
	    else
	      echo "A ação digitada não existe... use:"
				echo $0" < plan | apply | destroy >"
				echo
				exit 1
	  fi
	  ;;
	571571740496)
	  echo
	  echo "Iniciando a configuração do $TFSTATE de Desenvolvimento..."
	  terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/DEV/lambda-ke3/$TFSTATE" -backend-config="region=us-east-1"
	  echo
	  if [ "$1" = "plan" ]
	  then
	    terraform plan -input=false -var 'environment=DEV'
			elif [ "$1" = "apply" ]
	    then
	      terraform apply -input=false -var 'environment=DEV'
			elif [ "$1" = "destroy" ]
	    then
	      terraform destroy -input=false -var 'environment=DEV'
	    else
	      echo "A ação digitada não existe... use:"
				echo $0" < plan | apply | destroy >"
				echo
				exit 1
	  fi
	  ;;
	853597947141)
	  echo
	  echo "Iniciando a configuração do $TFSTATE de Homologação..."
	  terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/HOM/lambda-ke3/$TFSTATE" -backend-config="region=us-east-1"
	  echo
		if [ "$1" = "plan" ]
	  then
	    terraform plan -input=false -var 'environment=HOM'
			elif [ "$1" = "apply" ]
	    then
	      terraform apply -input=false -var 'environment=HOM'
			elif [ "$1" = "destroy" ]
	    then
	      terraform destroy -input=false -var 'environment=HOM'
	    else
	      echo "A ação digitada não existe... use:"
				echo $0" < plan | apply | destroy >"
				echo
				exit 1
	  fi
	  ;;
	131542353379)
	  echo
	  echo "Iniciando a configuração do $TFSTATE de Produção..."
	  terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/PRD/lambda-ke3/$TFSTATE" -backend-config="region=us-east-1"
	  echo
		if [ "$1" = "plan" ]
	  then
	    terraform plan -input=false -var 'environment=PRD'
			elif [ "$1" = "apply" ]
	    then
	      terraform apply -input=false -var 'environment=PRD'
			elif [ "$1" = "destroy" ]
	    then
	      terraform destroy -input=false -var 'environment=PRD'
	    else
	      echo "A ação digitada não existe... use:"
				echo $0" < plan | apply | destroy >"
				echo
				exit 1
	  fi
	  ;;
	*)
	  echo
	  echo "Você está tentando usar o terraform em uma conta diferente da:"
	  echo "- redeci"
		echo "- rededev"
		echo "- redehomolog"
		echo "- redeprd"
	  echo
	  exit 1

esac
exit
