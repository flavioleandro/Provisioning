#!/bin/bash

TFSTATE="dynamodb-pvs.tfstate"
SIGLA="KE3"

if [ $# -eq 0 ]
	then
	echo
	echo "Favor informar como argumento a ação desejada."
	echo $0" < plan | apply | destroy >"
	echo
	exit 1
fi

if [ $1 == "plan" ]; then
	echo
	elif [ $1 == "apply" ]; then
		echo
	elif [ $1 == "destroy" ]; then
		echo
	else
	echo
	echo "A ação digitada não existe... use:"
	echo $0" < plan | apply | destroy >"
	echo
	exit 1
fi

ACCOUNT_ID=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep accountId | awk '{print $3}'|tr -d \"\,)

case $ACCOUNT_ID in
	864401998850)
	AMBIENTE="CI"
	;;
  571571740496)
	AMBIENTE="DEV"
	;;
	853597947141)
	AMBIENTE="HOM"
	;;
	131542353379)
	AMBIENTE="PRD"
	;;
	*)
	echo
	echo "Você está tentando usar o terraform em uma conta diferente da:"
	echo "- redeci"
	echo "- rededev"
	echo "- redehomolog"
	echo "- redeprd"
	echo
	exit 1
esac

echo "Iniciando a configuração do $TFSTATE de $AMBIENTE..."
echo
terraform init -backend=true -backend-config="bucket=redecard-terraform" -backend-config="key=$SIGLA/$AMBIENTE/dynamodb-ke3/$TFSTATE" -backend-config="region=us-east-1"
terraform $1 -input=false -var "environment=$AMBIENTE" #-auto-approve
