# Fargate with Terraform

Example repository to deploy an ECS cluster hosting a web application.
