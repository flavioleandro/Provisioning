# Backend Go

Como consigo realizar o build da aplicação?

* Garanta que o **go** esteja instalado
* Instale as dependências descritas no block **import** do arquivo **main**.go
* Realize o build usando o próprio comando **go**