Considerando as aplicações presentes neste repositório detalhadas abaixo, precisamos de uma stack que permita a comunicação entre ambas e o acesso de desenvolvedores.

* **Aplicação Frontend** - Aplicação em Python com Flask expondo na porta 8000 um formulário de criação de usuário contendo os campos ID e Name que realiza uma chamada Post com tais dados para a aplicação Backend.

* **Aplicação Backend** - Aplicação em Go (Golang) expondo na porta 8080 o CRUD de Usuários e armazena em um banco Sqlite3 local.

## Como entregar sua solução?

1) Clone do repositório

2) Realize as alterações necessárias para construção/automação da stack. Considere um ambiente local (máquina do desenvolvedor) ou nosso provedor de cloud (AWS ou GCP).

3) Adicione e commit todos os arquivos criados/alterados (todos mesmo)

4) Gere um patch conforme comando de exemplo abaixo

*Para gerar o patch:*
```
git format-patch origin/master --stdout > seu_nome.patch
```
## Requisitos

* Crie imagens Docker para ambas as aplicações. 
* Preencher este arquivo README.md com os detalhes, linha de raciocínio e dicas para os desenvolvedores que utilizarão a solução.
* Considere que os desenvolvedores estão iniciando carreira e precisarão de mais detalhes de como executar a solução.
* A Stack pode usar os recursos do próprio desenvolvedor(ex. VirtualBox, Docker, Docker-Compose) ou recursos de um provedor de cloud (AWS)
* Não é necessário a criação de um pipeline. Considere que sua solução fará o bootstrap da Stack em questão.
* Não se preocupe em montar uma solução complexa. Dê preferência em montar uma solução simples que permita que o desenvolvedor realize melhorias.
* Apresente um desenho macro de arquitetura de sua solução.

* Sinta-se a vontade para realizar melhorias no código das aplicações, caso julgue necessário.



## Execução

1. Faça o build das imagens com o comando docker-compose build;
2. Faça a inicialização da aplicação com o comando docker-compose up;
3. Acesse via browser o endereço http://localhost:32040/healthz para verificar ser o backend esta executando;
4. Acesse via browser o endereço http://localhost:32030 para verificar se o frontend está funcionando;
5. Inclua um usuário na página exibida no item 6;
6. Liste os usuário no browser através do endereço http://localhost:32040/users;