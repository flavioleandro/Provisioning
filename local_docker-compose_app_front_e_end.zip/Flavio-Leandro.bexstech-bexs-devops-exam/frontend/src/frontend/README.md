# Frontend Python

Como consigo realizar o build da aplicação?

* Garanta que o **python** esteja instalado
* Utilize o comando **virtualenv** e ative um ambiente virtual.
* Instale as dependências descritas em **requirements.txt**
* Use o python para rodar o arquivo **frontend**.py